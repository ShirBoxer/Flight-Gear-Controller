package model;

public interface Command {
	public double doCommand(String[] code);
}
