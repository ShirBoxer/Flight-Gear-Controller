package model;

public interface Expression {
	public double calculate();
}
